GrowTH — HIGH-FIDELITY screen exports
23 screens x 2 viewports (desktop 1440px, mobile 390px), SVG.
Real palette and copy, editable text layers, vector icons, nested layer tree.
Drag straight onto a Figma canvas, or File > Import.
Fonts referenced by name (Inter, Manrope, JetBrains Mono) - all on Google Fonts.
