GrowTH — LOW-FIDELITY wireframe sketches
23 screens x 2 viewports (desktop 1440px, mobile 390px), PNG @2x.
Greyscale, placeholder text bars, no brand colour. For presentation and design review.
